<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Geofence extends Model
{
    protected $guarded = [];
}
