<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/map', 'GeofenceController@index');
Route::post('/geofence', 'GeofenceController@store');
Route::get('/show-data', 'GeofenceController@show');
Route::post('/delete-polygon', 'GeofenceController@destroy');
Route::get('/delete-old-points', 'GeofenceController@delete_old_point');
Route::post('/session-set', 'GeofenceController@set_session');
Route::post('/update', 'GeofenceController@update');


Route::get('/find-place', 'GeofenceController@place');

// Dragabel

Route::get('/drag', 'GeofenceController@drag');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
