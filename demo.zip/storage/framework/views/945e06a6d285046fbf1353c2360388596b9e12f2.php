<!DOCTYPE html>
<html>
<head>
	<title>Map</title>
</head>
<body>
	<div id="map"></div>

<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>

<script type="text/javascript">
	var map;
	var myLatLng;
$(document).ready(function(){
	 $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });
	$.ajax({
		url: 'show-data',
		type: 'GET',
	})
	.done(function(res) {
		$.each(function(i, val) {
			console.log('ik');
			var getlatvalue = val.lat;
			var getlngvalue = val.lng;
			var myLatLng = new google.maps.LatLng(getlatvalue, getlngvalue);
			createMap(myLatLng);
		});
		
	})
	.fail(function() {
		console.log("error");
	})
	
	geoLocationInit();
	function geoLocationInit()
	{
		if(navigator.geolocation)
		{
			navigator.geolocation.getCurrentPosition(success, fail);
		}
		else
		{
			alert('Browser not Supported'); 
		}
	}

	function success(myLatLng)
	{
		createMap(myLatLng);
	}

	function fail()
	{
		alert('Someting went wrong');
	}

	function createMap(myLatLng)
	{
		map = new google.maps.Map(document.getElementById('map'), {
          center: myLatLng,
          zoom: 12
        });
        var marker = new google.maps.Marker({
		    position: myLatLng,
		    map: map
		 });
	}
	function createMarker(latlng, icn, name)
	{
		var marker = new google.maps.Marker({
		    position: latlng,
		    map: map,
		    icon: icn,
		    title: name
		 });
	}

});
</script>
  <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyACLTLeNgkCI8smLndudh4LmL_P2NMWp5g">
    </script>
</body>
</html>