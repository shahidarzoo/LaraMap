function registerMapDragHandler(aMap) 
{

    var map = aMap;

    g.event.addListener(map, 'click', function(event) {
        createLineBeingDragged(map, event.latLng);
    });

    function createLineBeingDragged(map, pos) {
        var line = new g.Polyline({map: map, path: [pos, pos]});
        g.event.addListener(map, 'mousemove', function(event) {
            line.getPath().setAt(1, event.latLng);
        });
        g.event.addListener(line, 'click', function(event) {
            g.event.clearListeners(map, 'mousemove');
            g.event.clearListeners(line, 'click');
            createMarkersForLine(map, line);
        });

        function createMarkersForLine(map, line) {
            var startMarker = createMarker(line, 0);
            var endMarker = createMarker(line, 1);
            startMarker.nextMarker = endMarker;
            endMarker.previousMarker = startMarker;
        }

        function createMarker(line, pathPos) {
            var position = line.getPath().getAt(pathPos);
            var marker = new g.Marker({map: map, position: position, visible: true, flat: true, draggable: true, raiseOnDrag: false});

                // Marker functions
                marker.getPathIndex = function() {
                    if (this.previousMarker != null) {
                        return this.previousMarker.getPathIndex() + 1;
                    } else {
                        return 0;
                    }
                }

                marker.startDrag = function(pos) {
                    if (!marker.previousMarker || !marker.nextMarker) {
                        line.getPath().insertAt(marker.getPathIndex(), pos);
                        var newMarker = createMarker(line, marker.getPathIndex());
                        if (marker.nextMarker) {
                            newMarker.previousMarker = marker;
                            newMarker.nextMarker = marker.nextMarker;
                            newMarker.nextMarker.previousMarker = newMarker;
                            marker.nextMarker = newMarker;
                        } else {
                            newMarker.nextMarker = marker;
                            newMarker.previousMarker = marker.previousMarker;
                            newMarker.previousMarker.nextMarker = newMarker;
                            marker.previousMarker = newMarker;
                        }
                    }
                }

                marker.beingDragged = function() {
                    line.getPath().setAt(marker.getPathIndex(), marker.getPosition());
                }

                // Listeners
                g.event.addListener(marker, 'dragstart', function(event) {
                    marker.startDrag(event.latLng);
                });

                g.event.addListener(marker, 'drag', function(event) {
                    marker.beingDragged();
                });

                g.event.addListener(marker, 'click', function(event) {
                    var length = g.geometry.spherical.computeLength(line.getPath()) / 1000;
                    var infoWindow = new g.InfoWindow(
                    {
                        content: "&lt;ul&gt;&lt;li&gt;Line length: " + length.toFixed(2) + " km&lt;/li&gt;"+
                        "&lt;li&gt;Latitude: " + marker.getPosition().lat().toFixed(6) + "&lt;/li&gt;"+
                        "&lt;li&gt;Longitude: " + marker.getPosition().lng().toFixed(6) + "&lt;/ul&gt;"
                    });
                    infoWindow.open(map, marker);
                });

                return marker;
            }
        }
    }